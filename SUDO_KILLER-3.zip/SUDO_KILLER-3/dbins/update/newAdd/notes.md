This folder should not be deleted! It will be used as a temporary location for new and downloaded dangerous bins.
